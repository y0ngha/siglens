# test 2026-10-24: 사전 등록과 다른 점

## D1. 2회차 취소 (사용자 결정, 2026-10-24 11:4x KST)
- 사전 등록: 문항 186개 × 2회(1회차 계정 B, 2회차 계정 C, 2시간 이상 간격). DESIGN_v2 §2, RUNBOOK §5.
- 실제: 1회차만 실행했다. 대상 5개 모두 2회차를 하지 않는다.
- 사유: 비용. 1회차 Claude(claude-opus-5-5, web_search_20260209)가 136문항 시점에 입력 1,711만 토큰, 웹 검색 1,757회를 썼다.
  - 검색이 한 번 일어날 때마다 대화 전체를 다시 보낸다. 하네스는 프롬프트 캐시를 쓰지 않는다(캐시 적중 0).
  - 이 속도면 Claude 한 대상만 2회차까지 약 $300이 든다. 사전 등록한 전체 예산($200~400)을 넘는다.
- 결정 시점: 1회차 실행 중. 2회차 결과는 하나도 보지 않았다(실행 전이다). 1회차 점수도 아직 채점 전이다. 그래서 결과를 보고 고른 선택이 아니다.
- 영향
  - 사라지는 지표: "2회 반복 일치율"과 SiglensAI 캐시 재사용률(DESIGN_v2 §6 보고 항목).
  - 각 점수는 회차당 1개 표본으로 계산한다. `bench.stats`는 문항별로 회차 평균을 내므로 그대로 동작한다. 신뢰구간(종목→문항 2단계 군집 부트스트랩)의 계산 방식도 같지만, 회차 간 변동은 반영되지 않는다.
  - 공개 페이지와 BENCHMARK.md에 이 편차를 명시한다.
- 하네스 코드와 사전 등록 해시는 바꾸지 않았다.

## D2. Claude 미측정 50문항 (API 크레딧 소진, 사용자 결정으로 재전송하지 않음)
- 2026-10-24 11:33 KST 무렵부터 Claude 요청이 모두 `invalid_request_error: Your credit balance is too low` 오류를 받았다.
- 그 뒤의 Claude 문항은 모두 `infra_failed`로 기록됐다. Claude의 유효 응답은 136/186이다.
- 사용자 결정(11:5x KST): 충전 후 재전송하지 않고 136문항으로 확정한다.
  - 대안이던 서브에이전트나 claude.ai로 대체하는 방법은 쓰지 않았다. 시스템 프롬프트·도구·제품이 달라 같은 조건이 아니기 때문이다.
- 빠진 문항은 사실상 무작위다. 송신 순서가 시드 고정 셔플(`seed_sha256:round`)이고, 빠진 것은 그 순서의 뒤쪽이다.
  - 풀별: primary 34/120, L5 10/30, L4 4/20, aux 2/16
  - 시장별: 한국 17/62, 미국 33/124
  - 모두 약 27% 안팎으로, 전체 구성과 비례한다.
- 영향과 처리
  - SiglensAI 대 Claude 대비는 `bench.stats`가 두 대상이 함께 답한 문항(136)만으로 계산한다. 신뢰구간은 약 √(186/136) ≈ 1.17배 넓어진다.
  - 대상별 절대 점수 표는 Claude의 표본이 다르다. 그래서 136문항 공통 부분집합 점수를 함께 싣는다.

## D3. 채점에서 Claude API 제외, DeepSeek로 대체 (사용자 결정, 2026-10-24 11:5x KST)
- 원인: D2와 같다(Anthropic 크레딧 소진, 충전하지 않음). 사전 등록된 채점은 Claude API를 두 곳에서 쓴다.
  - 객관 추출기 `claude-sonnet-5-5`
  - L4·L5 심사위원 `claude-opus-5-5`
- 바꾼 것: `override/grading_d3.py`가 실행 중인 프로세스만 패치한다. `bench/`는 사전 등록 해시와 같다(`publish.verify_prereg` OK).
  - 객관 추출기 쌍: `gpt-6.1-sol` + `deepseek-flash`(temperature 0, thinking off, JSON 모드). L4 수치 추출 쌍도 같다.
  - L4·L5 심사위원: gpt, gemini, deepseek(claude 제외).
  - 대비별 중립 심사위원(§15.5): 아래 표와 같다. 대비에 들어간 쪽은 심사하지 않는다는 원칙은 그대로 지킨다.

| 대비 | 원래 | 바꾼 뒤 |
|---|---|---|
| vs gpt | claude | deepseek |
| vs gemini | gpt + claude | gpt + deepseek |
| vs claude | gpt | gpt |
| vs deepseek | gpt + claude | gpt |

- 검증: dev2 SiglensAI 응답 41문항의 객관 채점을 새 추출기 쌍으로 다시 했다(`scores/dev2-d3check`). 원래 쌍(gpt + claude)과 판정이 다른 문항은 0건이었다.
- 한계
  - SiglensAI 대 DeepSeek의 L4·L5 대비는 심사위원이 gpt 하나뿐이다.
  - DeepSeek가 vs gpt·vs gemini 대비를 심사한다. DeepSeek는 대비 당사자가 아니지만 측정 대상이기도 하다.
- 명령(RUNBOOK §7·§8의 grade·grade_l45·stats를 대체한다. refresh는 그대로 쓴다):
  ```sh
  uv run python -m override.grading_d3 grade     --set test --run-id test-2026-10-24 --targets siglens,gpt,gemini,claude,deepseek
  uv run python -m override.grading_d3 grade_l45 --set test --run-id test-2026-10-24 --targets siglens,gpt,gemini,claude,deepseek
  uv run python -m override.grading_d3 stats     --set test --run-id test-2026-10-24
  ```

## D4. 한국 정답을 KRX 공식값으로 다시 확정하지 않음, Yahoo 잠정값으로 확정 (사용자 결정, 2026-10-24 12:0x KST)
- 사전 등록: 한국 일봉형 정답은 data.go.kr(KRX 공식, D+1 영업일 공개)로 다시 확정한다(DESIGN_v2 §15.9, RUNBOOK §8).
- 실제: `bench.refresh --markets kr`를 실행하지 않는다. 한국 정답은 생성 때의 Yahoo 잠정값이다. 미국은 Nasdaq 공식값으로 확정한다.
- 근거: 앞선 세 번의 잠정→공식 확정(dev, dev2, rehearsal_dev2)에서 한국 정답 변경 16건을 비교했다.
  - 15건은 지표값 차이가 0.003% 이하였다(RSI·MACD 등).
  - 1건은 거래량 비율(T19)의 1.8% 차이였다. Yahoo와 KRX의 거래량 집계 차이로 보이며, 허용오차는 3%다.
- 남는 위험: test의 한국 T19 1문항(test-primary-T19-02). 답이 두 값 사이의 경계에 걸리면 직접 판정하고, 사유를 adjudications.json에 남긴다.
- T04 시가총액: 공식 상장주식수(직전 공개일)에 Yahoo 종가를 곱한 값을 그대로 쓴다.

## D5. 1회차 뒤 발견한 채점 결함 3건, 모든 대상에 같은 규칙으로 수정 (2026-10-24 13:xx KST)
발견 경위: 1회차 채점 뒤, 최종 숫자를 내기 전에 오답 원인을 문항별로 점검했다. 그중 "답한 대상이 모두 오답"인 문항과 대상 간 같은 패턴을 찾았다. 아래 수정은 `override/grading_d3.py`에 있다. bench/는 무수정이다.

1. **T11·T23 부호.** "52주 고점보다 몇 % 낮은가", "최고가 대비 하락률은"의 정답이 음수로 저장돼 있고 `sign_matters=True`였다. 그래서 자연스러운 답("35.45% 낮아요" → 35.45)이 모두 오답이 됐다.
   - 두 값은 정의상 0 이하라 부호에 정보가 없다. 그래서 크기로 비교한다.
   - 영향: GPT는 수정 전에도 음수로 쓴 2문항만 정답이었다. 다른 대상은 크기가 맞아도 오답이었다.
   - T23의 "장중 고가 기준" 답은 사전 등록된 관행 함정이라 그대로 오답이다(`convention_mismatch`).
2. **as-of 날짜 규칙.** 실행일이 토요일(2026-10-24)이라 D(10/23) 이후 거래일이 없다. 그런데 답변의 조회 시각(10/24)을 as-of로 읽어 오답 처리했다.
   - D 뒤로 조회일까지 이어지는 비거래일(주말)은 D와 같은 세션으로 본다.
   - 영향: SiglensAI T08_kospi 1건. 값 5,550.30이 정답과 같다.
3. **T26-03(JBHT) 정답 오류.** JBHT는 2010년 이후 XBRL `Revenues` 태그를 쓰지 않는다. 그래서 생성기가 2010-Q3 값(period end 2010-09-30)을 정답으로 만들었다.
   - 다섯 대상 모두 실제 최신 10-Q(2026-Q3, 10/23 제출) 기준 약 20.4%로 답했다.
   - 정답을 고쳐 넣지 않고, 모든 대상에서 이 문항을 뺐다(primary 120 → 119).
- 판정 대기 문항 처리(`adjudications.json`, 57건)
  - 기본: 추출기 둘이 같은 대표값을 읽었으면 그 값 하나를 사전 등록 규칙으로 채점했다. 대표값 대신 범위만 제시했으면 사전 등록된 범위 규칙을 적용했다.
  - 나머지 19건은 직접 판정했다. "확인하지 못했다"면서 덧붙인 추정치는 미시도로 판정했다(dev 판정 선례와 같은 기준). 사유는 건별로 남겼다.
- 판정자: 측정 대상이 아닌 오케스트레이터(Claude Opus 5.5, 이 세션)다. 이 세션은 Claude API 대상과 같은 모델 계열이다. 그래서 수동 판정 19건 중 Claude 대상 건(7건)의 사유를 공개 데이터에 그대로 남긴다.
